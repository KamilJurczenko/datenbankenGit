/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.kuechenstudio.model;

/**
 *
 * @author cpaun
 */
public class Product {
    
    	private int id;    
	private String name;    
	private float preis;
	private String beschreibung;
	private String bildpfad;
        private int stückzahl;
        
        
        public int getStückzahl(){
            return stückzahl;
        }       
        public void setStückzahl(int stückzahl) {
		this.stückzahl = stückzahl;
	}
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public float getpreis() {
		return preis;
	}
	public String getBeschreibung() {
		return beschreibung;
	}
	public void setBeschreibung(String beschreibung) {
		this.beschreibung = beschreibung;
	}
	public String getBildpfad() {
		return bildpfad;
	}
	public void setBildpfad(String bildpfad) {
		this.bildpfad = bildpfad;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setPreis(float preis) {
		this.preis = preis;
	}
	public Product(int id, String name, float preis, String beschreibung,
                String bildpfad, int stückzahl) {
		this.id = id;
		this.name = name;
		this.preis = preis;
		this.beschreibung = beschreibung;
		this.bildpfad = bildpfad;
                this.stückzahl = stückzahl;             
	}
        public Product()
        {
            super();
        }
}
