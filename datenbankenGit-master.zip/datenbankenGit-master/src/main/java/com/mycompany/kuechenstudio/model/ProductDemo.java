/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.kuechenstudio.model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author cpaun
 */

public class ProductDemo {
    
    private Product product = new Product();
    
    public Product getProduct(){
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }
    
    public String index() {
        return "index";
    }
    
    public List<Product> findAll(){
        List<Product> productsList = new ArrayList<>();
        
            productsList.add(new Product(1,"Kühlschrank",400f, "weiß",
                    "/images/Kühlschrank.jpg",1));    
            productsList.add(new Product(2,"Tisch ",300f, "braun",
                    "/images/Küchentisch.jpg",5));       
            productsList.add(new Product(3,"Schrank1",150f, "klein",
                    "/images/Küchenschrank_klein.jpg",3));   
            productsList.add(new Product(4,"Schrank2",200f, "groß",
                    "/images/Küchenschrank_groß.jpg",2));   
            productsList.add(new Product(5,"Spülmaschine",350f,"schnell",
                    "/images/Spülmaschine.jpg",6)); 
            
        return productsList;
    }

    
  
		

}
