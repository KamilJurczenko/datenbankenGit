/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package com.mycompany.kuechenstudio.controller;

import javax.inject.Named;
import javax.enterprise.context.Dependent;

/**
 * Backing-Bean für Registrierungs Prozess
 * @author kamil
 */
@Named(value = "registerBean")
@Dependent
public class RegisterBean {

    /**
     * Creates a new instance of RegisterBean
     */
    public RegisterBean() {
    }
    
}
